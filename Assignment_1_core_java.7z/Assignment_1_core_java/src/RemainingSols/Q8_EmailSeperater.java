package RemainingSols;

public class Q8_EmailSeperater {

	public static void main(String[] args) {

		String emails = "sohil@email.com,naveen@email.com,surendra@email.com,rohit@email.com,rang@email.com";
		String[] emailList = emails.split(",");
		for (String email : emailList) {
			System.out.println(email);
		}
	}

}
