package RemainingSols;

public class Q5_a_FibonacciSeries {

	public static void main(String args[]) {
		int start, mid, end = 0;

		start = 0;
		mid = 1;
		System.out.print(start + "  ");
		System.out.print(mid + "  ");
		for (; end < 50;) {
			end = start + mid;
			start = mid;
			mid = end;
			System.out.print(mid + "  ");
		}

	}

}
