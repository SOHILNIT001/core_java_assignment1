package RemainingSols;

import java.util.Scanner;

public class Q4_PrimeNumber {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a number :");
		int enteredNum = scan.nextInt();
		boolean flag = true;

		for (int i = 2; i < enteredNum; i++) {
			if (enteredNum % i == 0) {
				flag = false;
				break;
			}
		}

		if (flag == true) {
			System.out.println(enteredNum + " is a Prime Number");
		} else {
			System.out.println(enteredNum + " is not a Prime Number");
		}

	}
}
