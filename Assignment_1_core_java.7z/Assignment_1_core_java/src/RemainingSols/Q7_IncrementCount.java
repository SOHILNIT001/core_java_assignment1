package RemainingSols;

public class Q7_IncrementCount {

	int count=0;
	public static void main(String[] args) {

		Q7_IncrementCount ic = new Q7_IncrementCount();
		int total = ic.incrementCount(ic.count);
		System.out.println(total);
	}
	public int incrementCount(int count) {
		count++;
		return count;
	}

}
