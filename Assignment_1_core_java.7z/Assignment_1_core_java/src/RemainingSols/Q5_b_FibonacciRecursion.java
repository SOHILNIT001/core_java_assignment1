package RemainingSols;

public class Q5_b_FibonacciRecursion {
	public static void main(String args[]) {
		int firstEle = 0, secondEle = 1;
		fibseries(firstEle, secondEle);
	}

	private static void fibseries(int ele1, int ele2) {
		if(ele1==0) {
			System.out.print(ele1+"  ");
		}
		if (ele1 >= 100) {
			return;
		}
		System.out.print(ele2 + "  ");
		fibseries(ele2, ele1 + ele2);
	}
}
