package RemainingSols;

enum Season {
	WINTER, SPRING, SUMMER, FALL
};

public class Q9_enumProblem {
	public static void main(String[] args) {
		Season season = Season.SUMMER;

		System.out.println(season);

		if (season != Season.FALL) {
			System.out.println("Season is not FALL");
		} else {
			System.out.println("Season is FALL");
		}

		System.out.println("Season is " + myEnum(season));
	}

	public static Season myEnum(Season season) {
		return season;
	}

}